import {CollectionViewer, SelectionChange, DataSource} from '@angular/cdk/collections';
import {FlatTreeControl} from '@angular/cdk/tree';
import {Component, Injectable} from '@angular/core';
import {BehaviorSubject, merge, Observable} from 'rxjs';
import {map} from 'rxjs/operators';


export class DynamicFlatNode {
  constructor(
    public item: string,
    public level = 1,
    public expandable = false,
    public isLoading = false,
  ) {}
}



@Injectable({providedIn: 'root'})
export class DynamicDatabase {

  apiData: any = [
    {
        "TransactionId": "0a06243e-7dfe-11ec-bc07-0a0f0d3e0000",
        "UserId": "Sanjai",
        "TransactionDetails": [
            {
                "TransactionState": "INPROGRESS",
                "TransactionTime": "2022-01-25T11:44:18.525 EST",
                "Type": "INFO",
                "Log": "com.bcbsma.web.api.getclaimdetailsservice.getclaimdetails - USER ID - sanjai\n",
                "ApigeeTransactionId": "135c5349-e3d1-8a3e-b881-e10c7c18412e",
                "ServerInfo": "sameplservr",
                "CorrelationId": "0a06243e-7dfe-11ec-bc07-0a0f0d3e0000",
                "UiTransactionId": "5f3bf8e2-33d3-46f4-8deb-8acf1ce058f8",
                "Date": "2022-01-25 11:44:18.525 EST",
                "Thread": "87",
                "TransactionId": "0a06243e-7dfe-11ec-bc07-0a0f0d3e0000"
            },
            {
                "TransactionState": "INPROGRESS",
                "TransactionTime": "2022-01-25T11:44:35.780 EST",
                "Type": "INFO",
                "Log": "com.bcbsma.web.api - USER ID - sanjai\n",
                "ApigeeTransactionId": "",
                "ServerInfo": "sameplservr",
                "CorrelationId": "144ee98a-7dfe-11ec-bc07-0a0f0d3e0000",
                "UiTransactionId": "WEB_v3.0_41cc3b95-02e3-4d1c-8908-8d3ec2c68ec1",
                "Date": "2022-01-25 11:44:35.780 EST",
                "Thread": "234",
                "TransactionId": "144ee98a-7dfe-11ec-bc07-0a0f0d3e0000"
            }
        ]
    },
    {
        "TransactionId": "0a06243e-7dfe-11ec-bc07-0a0f0d3e0000",
        "UserId": "Sanjai",
        "TransactionDetails": [
            {
                "TransactionState": "INPROGRESS",
                "TransactionTime": "2022-01-25T11:44:18.525 EST",
                "Type": "INFO",
                "Log": "com.bcbsma.web.api.getclaimdetailsservice.getclaimdetails - USER ID - sanjai\n",
                "ApigeeTransactionId": "135c5349-e3d1-8a3e-b881-e10c7c18412e",
                "ServerInfo": "sameplservr",
                "CorrelationId": "0a06243e-7dfe-11ec-bc07-0a0f0d3e0000",
                "UiTransactionId": "5f3bf8e2-33d3-46f4-8deb-8acf1ce058f8",
                "Date": "2022-01-25 11:44:18.525 EST",
                "Thread": "87",
                "TransactionId": "0a06243e-7dfe-11ec-bc07-0a0f0d3e0000"
            },
            {
                "TransactionState": "INPROGRESS",
                "TransactionTime": "2022-01-25T11:44:35.780 EST",
                "Type": "INFO",
                "Log": "com.bcbsma.web.api - USER ID - sanjai\n",
                "ApigeeTransactionId": "",
                "ServerInfo": "sameplservr",
                "CorrelationId": "144ee98a-7dfe-11ec-bc07-0a0f0d3e0000",
                "UiTransactionId": "WEB_v3.0_41cc3b95-02e3-4d1c-8908-8d3ec2c68ec1",
                "Date": "2022-01-25 11:44:35.780 EST",
                "Thread": "234",
                "TransactionId": "144ee98a-7dfe-11ec-bc07-0a0f0d3e0000"
            }
        ]
    }
]


  dataMap = new Map<any, any[]>();
    rootLevelNodes: string[] = [];


    populatingMap(): void {

      for (let item of this.apiData) {
        let tempArr = [];
        for (let details of item.TransactionDetails){
           tempArr.push(details.Log);
        }
                  this.dataMap.set(item.TransactionId, tempArr);
                  this.rootLevelNodes.push(item.TransactionId)

      }
      console.log(this.dataMap);
    }

  initialData(): DynamicFlatNode[] {
      this.populatingMap();

    return this.rootLevelNodes.map(name => new DynamicFlatNode(name, 0, true));

  }

  getChildren(node: string): string[] | undefined {
    return this.dataMap.get(node);
  }

  isExpandable(node: string): boolean {
    return this.dataMap.has(node);
  }
}


export class DynamicDataSource implements DataSource<DynamicFlatNode> {
  dataChange = new BehaviorSubject<DynamicFlatNode[]>([]);

  get data(): DynamicFlatNode[] {
    return this.dataChange.value;
  }
  set data(value: DynamicFlatNode[]) {
    this._treeControl.dataNodes = value;
    this.dataChange.next(value);
  }

  constructor(
    private _treeControl: FlatTreeControl<DynamicFlatNode>,
    private _database: DynamicDatabase,
  ) {}

  connect(collectionViewer: CollectionViewer): Observable<DynamicFlatNode[]> {
    this._treeControl.expansionModel.changed.subscribe(change => {
      if (
        (change as SelectionChange<DynamicFlatNode>).added ||
        (change as SelectionChange<DynamicFlatNode>).removed
      ) {
        this.handleTreeControl(change as SelectionChange<DynamicFlatNode>);
      }
    });

    return merge(collectionViewer.viewChange, this.dataChange).pipe(map(() => this.data));
  }

  disconnect(collectionViewer: CollectionViewer): void {}


  handleTreeControl(change: SelectionChange<DynamicFlatNode>) {
    if (change.added) {
      change.added.forEach(node => this.toggleNode(node, true));
    }
    if (change.removed) {
      change.removed
        .slice()
        .reverse()
        .forEach(node => this.toggleNode(node, false));
    }
  }



  toggleNode(node: DynamicFlatNode, expand: boolean) {
    const children = this._database.getChildren(node.item);
    const index = this.data.indexOf(node);
    if (!children || index < 0) {
      return;
    }

    node.isLoading = true;

    setTimeout(() => {
      if (expand) {
        const nodes = children.map(
          name => new DynamicFlatNode(name, node.level + 1, this._database.isExpandable(name)),
        );
        this.data.splice(index + 1, 0, ...nodes);
      } else {
        let count = 0;
        for (
          let i = index + 1;
          i < this.data.length && this.data[i].level > node.level;
          i++, count++
        ) {}
        this.data.splice(index + 1, count);
      }

      this.dataChange.next(this.data);
      node.isLoading = false;
    }, 1000);
  }
}


 @Component({
  selector: 'app-tree-view',
  templateUrl: './tree-view.component.html',
  styleUrls: ['./tree-view.component.css']
})
export class TreeViewComponent {
  constructor(database: DynamicDatabase) {
    this.treeControl = new FlatTreeControl<DynamicFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new DynamicDataSource(this.treeControl, database);

    this.dataSource.data = database.initialData();
  }

  treeControl: FlatTreeControl<DynamicFlatNode>;

  dataSource: DynamicDataSource;

  getLevel = (node: DynamicFlatNode) => node.level;

  isExpandable = (node: DynamicFlatNode) => node.expandable;

  hasChild = (_: number, _nodeData: DynamicFlatNode) => _nodeData.expandable;
}

